#ifndef __FILE_CONVERTER_H__
#define __FILE_CONVERTER_H__

bool Txt2Binary(char *inputFile, char *outputFile);
bool Binary2Txt(char *inputFile, char *outputFile);

#endif

