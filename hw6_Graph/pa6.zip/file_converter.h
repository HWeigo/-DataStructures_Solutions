#ifndef __FILE_CONVERTER_H__
#define __FILE_CONVERTER_H__


bool Binary2Txt(char *inputFile, char *outputFile);
void TableConstruct(char *filename);
void SequenceConstruct(char *filename);

#endif 
