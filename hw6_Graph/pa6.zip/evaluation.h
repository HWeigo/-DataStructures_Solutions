#ifndef __EVALUATION_H__
#define __EVALUATION_H__

bool Evaluation(char *inputFile, char *outputFile);

#endif
